﻿namespace SoftUni.NewFolder
{
    public static class Config
    {
        public const string ConnectionString
            = "Server=localhost\\sqltest,1433;Database=SoftUni;User=achkatam;Password=yourStrong(!)Password;TrustServerCertificate=True;";
    }
}
