﻿namespace P01_StudentSystem.Common
{ 
    public class Config
    {
        public const string ConnectionString
            = @"Server=localhost\sqltest,1433;Database=StudentSystem;User=achkatam;Password=yourStrong(!)Password;";
    }
}
