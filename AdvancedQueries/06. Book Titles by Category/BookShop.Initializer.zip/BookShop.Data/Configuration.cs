﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=localhost\\sqltest,1433;Database=BookShop;User=achkatam;Password=yourStrong(!)Password;";
    }
}
